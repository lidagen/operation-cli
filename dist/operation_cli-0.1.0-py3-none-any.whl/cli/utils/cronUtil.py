
def push_plus(token:str,cron:str,titel:str,content:str):
    """
    step1.创建一个cron,
    step2.写入sh
    step3.写入cron
    """
    print("TODO")