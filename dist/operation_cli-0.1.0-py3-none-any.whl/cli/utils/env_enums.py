from enum import Enum


class Env(Enum):
    LOCAL = 'local'
    REMOTE = 'remote'
