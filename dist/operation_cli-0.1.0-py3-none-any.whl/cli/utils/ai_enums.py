from enum import Enum


class Ai(Enum):
    DEEP_SEEK = 'deepseek'
    GEMINI= 'gemini'
    QIAN_WEN= 'qinwen'
