'''
本地部署开源大模型的完整教程：LangChain + Streamlit+ Llama
jenv versions

jenv add ...

jenv remove ...

jenv global

'''
def jenv():
    print()

'''
nvm list

nvm use ...

nvm install ...
'''
def nvm():
    print()

