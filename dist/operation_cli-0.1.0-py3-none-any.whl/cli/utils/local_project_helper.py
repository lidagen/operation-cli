import git

import os

'''
1.输入commit 
'''